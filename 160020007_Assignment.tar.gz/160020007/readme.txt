Please note that part a submission is done c and part b submission is done in cpp format.
Also parta.out is compiled version of part a while partb.out is complied version of part b.
