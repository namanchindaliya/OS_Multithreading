#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <wait.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

//using namespace std;
int item_to_produce=0;
int total_items, max_buf_size, num_workers;
pthread_cond_t empty=PTHREAD_COND_INITIALIZER, fill=PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
int count=0;
int cumcount=0;
int flag2=0;
//int item_to_consume;
// declare any global data structures, variables, etc that are required
// e.g buffer to store items, pthread variables, etc
struct Node{
    Node* next;
    int length;
};
Node* head;
void push(struct Node** head_ref,int len) 
  { 
      struct Node* nnode = (struct Node*) malloc(sizeof(struct Node)); 
      nnode->length= len;
      nnode->next = (*head_ref); 
      (*head_ref)= nnode; 
  }
void deleteNode(struct Node **head_ref) 
  { 
      Node* del=*head_ref;
      *head_ref=(*head_ref)->next;
      free(del);
  }

void print_produced(int num) {

  printf("Produced %d\n", num);
}

void print_consumed(int num, int worker) {

  printf("Consumed %d by worker %d \n", num, worker);
  
}


/* produce items and place in buffer (array or linked list)
 * add more code here to add items to the buffer (these items will be consumed
 * by worker threads)
 * use locks and condvars suitably
 */
void *generate_requests_loop(void *data)
{
  int thread_id = *((int *)data);
  while(1)
    {
    	pthread_mutex_lock(&mutex);
    	//printf("sda");
    	if(item_to_produce >= total_items) {
    		//printf("went to producer\n");
    		pthread_mutex_unlock(&mutex);
    		break;
    	}
    	while(count >= max_buf_size){
			pthread_cond_wait(&empty,&mutex);
    	}
    	//buf[count]=item_to_produce;
      push(&head,item_to_produce);
    	print_produced(item_to_produce);
    	count++;
    	//printf("***: %d \n",count);
    	
    	//printf("COunt: %d \n",count);
    	
    	item_to_produce++;
    	pthread_cond_signal(&fill);
    	pthread_mutex_unlock(&mutex);

    }
  return 0;
}

void *consume_requests_loop(void *data)
{
  int thread_id = *((int *)data);
  while(1)
    {
    	pthread_mutex_lock(&mutex);
    	// printf("lock acquired by %d\n",thread_id);
    	
    	if(cumcount==total_items){
    		printf("exit %d\n",thread_id);
    		// printf("lock released by %d\n",thread_id);
    		pthread_mutex_unlock(&mutex);
    		break;
    	}
    	while(count<=0){
    		count=0;
    		if(cumcount==total_items){
	    		// printf("exit %d\n",thread_id);
	    		
	    		flag2=1;
	    		break;
    		}
    		if(flag2==1){
    			break;
    		}
    		// printf("a\n");
    		pthread_cond_signal(&empty);
    		// printf("lock released and waiting by %d\n",thread_id);
			pthread_cond_wait(&fill,&mutex);
		}
		if(flag2==1){
			// printf("lock released by %d\n",thread_id);
				pthread_mutex_unlock(&mutex);
				pthread_cond_signal(&fill);
    			break;
    		}
    	if(cumcount>=total_items)
    		continue;
		count--;
    
    	print_consumed(head->length, thread_id);
      deleteNode(&head);
    	// printf("%d==%d, thread=%d\n",cumcount,total_items,thread_id);
    	cumcount++;
    	// printf("lock released by %d\n",thread_id);
    	pthread_mutex_unlock(&mutex);
    }
  return 0;
}

//write function to be run by worker threads
//ensure that the workers call the function print_consumed when they consume an item

int main(int argc, char *argv[])
{
 //printf("start");
  int master_thread_id = 0;
  pthread_t master_thread;
  item_to_produce = 0;
  item_to_produce = 0;
  
  if (argc < 4) {
    printf("./master-worker #total_items #max_buf_size #num_workers e.g. ./exe 10000 1000 4\n");
    exit(1);
  }
  else {
    num_workers = atoi(argv[3]);
    total_items = atoi(argv[1]);
    max_buf_size = atoi(argv[2]);
  }
  
  // Initlization code for any data structures, variables, etc
  int consumer_thread_id[num_workers];
  pthread_t consumer_thread[num_workers];

  head=NULL;
  //create master producer thread
  pthread_create(&master_thread, NULL, generate_requests_loop, (void *)&master_thread_id);

  //create worker consumer threads
  for(int i=0;i<num_workers;i++){
  	pthread_create(&consumer_thread[i],NULL,consume_requests_loop,(void *)& i);	
  }
  
  //wait for all threads to complete
  pthread_join(master_thread, NULL);
  for (int i = 0; i < num_workers; ++i)
  {
  	pthread_join(consumer_thread[i], NULL);
  }
  printf("master joined\n");
  //deallocate and free up any memory you allocated
  
  return 0;
}
